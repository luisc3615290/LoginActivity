package com.alu3615290.loginactivity.activities

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.alu3615290.loginactivity.R
import com.alu3615290.loginactivity.databinding.ActivityContactForm2Binding
import com.alu3615290.loginactivity.databinding.ActivityContactoFormBinding

class ContactoFormActivity : AppCompatActivity() {
    private lateinit var binding : ActivityContactForm2Binding

    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactForm2Binding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}