# Release 1.8.0 - 15/12/2024
- Splash Screen creado y funcionando

# Release 1.7.0 - 14/12/2024
- Ejercicio #1 Terminado
- Excepciones tratadas

# Release 1.6.0 - 14/12/2024
- Layout landscape terminado
- Strings EN terminados
- Con la lógica de campos vacíos para user/password

# Release 1.5.0 - 09/12/2024
- Añadiendo los intents, funcionan perfectamente

# Release 1.4.3 - 09/12/2024
- Ordenado el MainActivity.kt

# Release 1.4.2 - 09/12/2024
- Corregido activity_main.xml

# Release 1.4.1 - 09/12/2024
- Añadido logo POKEMON CAMP - nuevo activity_main.xml

# Release 1.3 - 08/12/2024
- Añadido botón de password hint

# Release 1.2 - 08/12/2024
- Quitadas las strings.xml del intento de crear activities 2

# Release 1.1 - 08/12/2024
- Quitadas las strings.xml del intento de crear activities

# Release 1.0 - 08/12/2024
- Sólo MainActivity.kt
- UI Completa
- Funcionan los botones
- Funcionan los snackbars 


# LoginActivity
Tarea para 2DAM de PMP
